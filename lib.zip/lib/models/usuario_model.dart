// lib/models/usuario_model.dart

// 1. Quitar import innecesario:
// Este import no se usa directamente en este archivo.
// import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

class UsuarioModel {
  // 2. Hacer las propiedades realmente finales.
  final String uid;
  final String nombre;
  final String correo;
  final String rol;
  final String? tokenNotificacion; // Nombre más descriptivo
  // final Timestamp creadoEn; // Reemplazado por un DateTime más útil

  // 3. Usar DateTime en lugar de Timestamp para facilidad de uso en la UI.
  final DateTime creadoEn;

  // 4. Hacer el constructor 'const' para mejor rendimiento.
  const UsuarioModel({
    required this.uid,
    required this.nombre,
    required this.correo,
    this.rol = 'user',
    this.tokenNotificacion,
    required this.creadoEn,
  });

  // 5. Crear un método 'copyWith' para facilitar la actualización de objetos.
  //    Es muy útil cuando quieres cambiar solo un campo (ej: actualizar el token).
  UsuarioModel copyWith({
    String? uid,
    String? nombre,
    String? correo,
    String? rol,
    String? tokenNotificacion,
    DateTime? creadoEn,
  }) {
    return UsuarioModel(
      uid: uid ?? this.uid,
      nombre: nombre ?? this.nombre,
      correo: correo ?? this.correo,
      rol: rol ?? this.rol,
      // Manejo especial para el token, permitiendo que sea nulo.
      tokenNotificacion: tokenNotificacion ?? this.tokenNotificacion,
      creadoEn: creadoEn ?? this.creadoEn,
    );
  }

  // 6. Hacer los métodos de conversión 'static' y 'factory'.
  //    Es el patrón recomendado para la serialización de datos.
  //    Ahora espera un Map, no un DocumentSnapshot, haciéndolo más flexible.
  factory UsuarioModel.desdeMapa(Map<String, dynamic> mapa, String id) {
    return UsuarioModel(
      uid: id,
      nombre: mapa['nombre'] ?? '',
      correo: mapa['correo'] ?? '',
      rol: mapa['rol'] ?? 'user',
      tokenNotificacion: mapa['tokenNotificacion'], // Ya es String? por lo que no necesita 'as String?'
      // Conversión segura de Timestamp de Firestore a DateTime de Dart.
      creadoEn: (mapa['creadoEn'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  // 7. 'toMap' ahora se llama 'aMapa' para consistencia en español.
  Map<String, dynamic> aMapa() {
    return {
      // No incluimos el 'uid' porque es el ID del documento en Firestore.
      'nombre': nombre,
      'correo': correo,
      'rol': rol,
      'tokenNotificacion': tokenNotificacion,
      // Se convierte de DateTime a Timestamp al guardar en Firestore.
      'creadoEn': creadoEn,
    };
  }
}

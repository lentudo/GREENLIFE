// lib/models/diary_entry_model.dart

import 'package:cloud_firestore/cloud_firestore.dart';

class DiaryEntryModel {
  final String id;
  final String plantId;
  final String notes;
  final String? photoUrl; // URL de Firebase Storage (tomada con el Sensor - U5)
  final Timestamp createdAt;

  DiaryEntryModel({
    required this.id,
    required this.plantId,
    required this.notes,
    this.photoUrl,
    required this.createdAt,
  });

  factory DiaryEntryModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return DiaryEntryModel(
      id: doc.id,
      plantId: data['plantId'] ?? '',
      notes: data['notes'] ?? '',
      photoUrl: data['photoUrl'] as String?,
      createdAt: data['createdAt'] as Timestamp,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'plantId': plantId,
      'notes': notes,
      'photoUrl': photoUrl,
      'createdAt': createdAt,
    };
  }
}
// lib/models/comment_model.dart

import 'package:cloud_firestore/cloud_firestore.dart';

class CommentModel {
  final String id;
  final String diaryId;
  final String userId; // ID del usuario que comenta
  final String ownerId; // ID del dueño del diario (a quien se notificará)
  final String text;
  final Timestamp createdAt;

  CommentModel({
    required this.id,
    required this.diaryId,
    required this.userId,
    required this.ownerId,
    required this.text,
    required this.createdAt,
  });

  factory CommentModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return CommentModel(
      id: doc.id,
      diaryId: data['diaryId'] ?? '',
      userId: data['userId'] ?? '',
      ownerId: data['ownerId'] ?? '',
      text: data['text'] ?? '',
      createdAt: data['createdAt'] as Timestamp,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'diaryId': diaryId,
      'userId': userId,
      'ownerId': ownerId,
      'text': text,
      'createdAt': createdAt,
    };
  }
}
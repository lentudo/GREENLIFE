// lib/models/plant_model.dart

import 'package:cloud_firestore/cloud_firestore.dart';

class PlantModel {
  final String id;
  final String userId;
  final String name;
  final String species;
  final Timestamp lastWatered;
  final int waterIntervalDays; // Base para la Notificación Local (U4)
  final GeoPoint? location; // Para el requisito GPS (U5)
  final Timestamp createdAt;

  PlantModel({
    required this.id,
    required this.userId,
    required this.name,
    required this.species,
    required this.lastWatered,
    required this.waterIntervalDays,
    this.location,
    required this.createdAt,
  });

  factory PlantModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return PlantModel(
      id: doc.id,
      userId: data['userId'] ?? '',
      name: data['name'] ?? 'Mi Planta',
      species: data['species'] ?? 'Desconocida',
      lastWatered: data['lastWatered'] as Timestamp,
      waterIntervalDays: data['waterIntervalDays'] ?? 7,
      location: data['location'] as GeoPoint?,
      createdAt: data['createdAt'] as Timestamp,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'name': name,
      'species': species,
      'lastWatered': lastWatered,
      'waterIntervalDays': waterIntervalDays,
      'location': location,
      'createdAt': createdAt,
    };
  }
}
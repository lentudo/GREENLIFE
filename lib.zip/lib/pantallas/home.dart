// lib/pantallas/home.dart

import 'package:flutter/material.dart';
import 'package:greenlife/pantallas/auth.dart';
import '../services/auth_servicio.dart'; // Asegúrate que la ruta sea correctaimport 'auth_screen.dart'; // Asegúrate de importar tu pantalla de autenticación

class HomeScreen extends StatelessWidget {
  // 1. Crea una instancia única y final de tu servicio de autenticación.
  //    Esto es más eficiente que crear una nueva cada vez.
  final AuthService _authService = AuthService();

  HomeScreen({super.key}); // El constructor debe ir después de las variables de instancia

  @override
  Widget build(BuildContext context) {
    // 2. Obtén el usuario actual usando el getter público que agregamos al servicio.
    //    Esto se hace aquí para poder usarlo fácilmente en el `build`.
    final user = _authService.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('GreenLife - Mis Plantas'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              // 3. Usa la instancia del servicio para cerrar sesión.
              await _authService.signOut();

              // 4. MUY IMPORTANTE: Redirige al usuario a la pantalla de login.
              //    `pushAndRemoveUntil` limpia todas las pantallas anteriores
              //    para que el usuario no pueda "volver atrás" a la pantalla de home.
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => AuthScreen()), // Reemplaza AuthScreen() con el nombre de tu pantalla de login si es diferente
                    (Route<dynamic> route) => false,
              );
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('¡Inicio de sesión exitoso!', style: TextStyle(fontSize: 24)),
            const SizedBox(height: 20),

            // 5. Muestra el UID del usuario de forma segura.
            //    Usa la variable `user` que definimos al inicio del `build`.
            Text('UID: ${user?.uid ?? "N/A"}'),

            const SizedBox(height: 20),
            const Text('Aquí irá la gestión de plantas (U4 y U5).'),
          ],
        ),
      ),
    );
  }
}

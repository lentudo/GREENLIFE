// lib/screens/auth_screen.dart

import 'package:flutter/material.dart';
import '../services/auth_servicio.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final AuthService _authService = AuthService();
  final _formKey = GlobalKey<FormState>();

  String _email = '';
  String _password = '';
  String _name = '';
  bool _isLogin = true; // Si es login (true) o registro (false)

  void _submitAuthForm() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      if (_isLogin) {
        // Lógica de LOGIN
        await _authService.signIn(_email, _password);
      } else {
        // Lógica de REGISTRO
        await _authService.signUp(_name, _email, _password);
      }
      // El StreamBuilder en main.dart manejará la navegación automática
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isLogin ? 'Iniciar Sesión' : 'Registrarse'),
      ),
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(20),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (!_isLogin) // Campo de nombre solo en registro
                    TextFormField(
                      decoration: const InputDecoration(labelText: 'Nombre'),
                      onSaved: (value) => _name = value!,
                      validator: (value) => value!.isEmpty ? 'Ingresa tu nombre' : null,
                    ),
                  TextFormField(
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'Correo Electrónico'),
                    onSaved: (value) => _email = value!,
                    validator: (value) => value!.isEmpty || !value.contains('@') ? 'Correo inválido' : null,
                  ),
                  TextFormField(
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Contraseña'),
                    onSaved: (value) => _password = value!,
                    validator: (value) => value!.length < 6 ? 'Contraseña debe tener al menos 6 caracteres' : null,
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _submitAuthForm,
                    child: Text(_isLogin ? 'ENTRAR' : 'REGISTRARME'),
                  ),
                  TextButton(
                    child: Text(_isLogin ? '¿Crear una cuenta?' : 'Ya tengo una cuenta'),
                    onPressed: () {
                      setState(() {
                        _isLogin = !_isLogin; // Cambia entre login y registro
                      });
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}